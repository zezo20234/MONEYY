// api/log-sms.js
// Your iPhone Shortcut sends each UrPay text here. This saves it as a "pending" purchase in your
// database; the app then shows a pop-up where you pick Hangout / Savings / PlayStation, or Decline.
// (Optional) it also pings your Discord webhook so you know to open the app.
//
// Works for texts sent LATE (queued on the phone while offline and sent once you are on Wi-Fi): the purchase
// time is read from the SMS itself ("09-10-2026 12:29", Riyadh time), or from a "received: <ISO time>" line the
// Shortcut adds, or from ?time=. A queued text that is sent twice is only saved once.
//
// Only ONE environment variable is needed: SMS_SECRET.
// URL (POST, SMS text as the body):  https://moneyy-sdwg.vercel.app/api/log-sms?user=Zezo&key=YOUR_SMS_SECRET
// The card digits in the SMS are never saved — only the amount and the store name.

import { createHash } from 'node:crypto';

const DB = (process.env.FIREBASE_DATABASE_URL || 'https://money-e560a-default-rtdb.firebaseio.com').replace(/\/$/, '');
const r2 = (n) => Math.round((Number(n) + Number.EPSILON) * 100) / 100;

// Accepts plain text, {"text": "..."} or anything else Shortcuts sends: it collects every piece of text it can find.
function collectText(v, out = []) {
    if (v == null) return out;
    if (typeof v === 'string') out.push(v);
    else if (Array.isArray(v)) v.forEach((x) => collectText(x, out));
    else if (typeof v === 'object') Object.values(v).forEach((x) => collectText(x, out));
    return out;
}
function readBody(req) {
    let b = req.body;
    if (!b) return '';
    if (Buffer.isBuffer(b)) b = b.toString('utf8');
    if (typeof b === 'string') {
        try { const j = JSON.parse(b); if (j && typeof j === 'object') return collectText(j).join('\n'); } catch { /* plain text */ }
        return b;
    }
    return collectText(b).join('\n');
}

// "amount:13:13.49" -> 13.49
function parseAmount(text) {
    const m = text.match(/amount\s*[:：]?\s*([^\n\r]*)/i);
    if (!m) return null;
    const nums = m[1].replace(/,/g, '').match(/\d+(?:\.\d+)?/g);
    if (!nums || !nums.length) return null;
    const v = Number(nums[nums.length - 1]);
    return v > 0 && v < 1e6 ? r2(v) : null;
}
function parseStore(text) {
    const m = text.match(/^\s*at\s*[:：]\s*(.+)$/im);
    return ((m && m[1].trim()) || 'UrPay purchase').slice(0, 80);
}

// The real purchase time. The SMS ends with "09-10-2026 12:29" (DD-MM-YYYY HH:MM, Riyadh time, UTC+3),
// so a purchase made outside and sent later from home still gets the time it was really made.
const RIYADH_MS = 3 * 60 * 60 * 1000;
const sane = (ms) => Number.isFinite(ms) && ms < Date.now() + 36e5 && ms > Date.now() - 400 * 864e5;
function parseSmsTime(text) {
    const m = text.match(/(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{4})[\s-]+(\d{1,2}):(\d{2})/);
    if (!m) return null;
    let [, a, b, y, hh, mm] = m.map(Number);
    let day = a, month = b;
    if (month > 12 && day <= 12) { day = b; month = a; } // tolerate MM-DD-YYYY
    const ms = Date.UTC(y, month - 1, day, hh, mm) - RIYADH_MS;
    return sane(ms) ? ms : null;
}
// Fallback: the Shortcut adds a line "received: 2026-10-09T12:29:41+03:00" (or ?time=) to every queued text.
function parseReceivedTime(text, queryTime) {
    const m = text.match(/^\s*received\s*[:：]\s*(\S+)/im);
    const raw = (m && m[1]) || queryTime;
    if (!raw) return null;
    const ms = /^\d{10,13}$/.test(String(raw)) ? (String(raw).length <= 10 ? Number(raw) * 1000 : Number(raw)) : Date.parse(raw);
    return sane(ms) ? ms : null;
}

// ---- Top-ups (money added to the card) ----
// UrPay's exact wording is unknown, so this looks for common words (English + Arabic).
const TOPUP_RE = /top[\s-]?up|topped|recharg|reload|\bloaded\b|deposit|funds?\s+added|money\s+added|balance\s+added|credited\s+to|credit(?:ed)?\s+via|via\s+wallet|شحن|إيداع|ايداع|تعبئة|اضافة\s*رصيد|إضافة\s*رصيد/i;
function isTopUp(text) { return TOPUP_RE.test(text); }
// Amount for a top-up: the "amount:" line if there is one, else the number next to SAR / SR / ⃁ / ر.س
function parseTopUpAmount(text) {
    const a = parseAmount(text);
    if (a) return a;
    const m = text.replace(/,/g, '').match(/(?:sar|sr|ر\.?\s?س|⃁)\s*(\d+(?:\.\d+)?)|(\d+(?:\.\d+)?)\s*(?:sar|sr|ر\.?\s?س|⃁)/i);
    const v = m ? Number(m[1] || m[2]) : NaN;
    return v > 0 && v < 1e6 ? r2(v) : null;
}
async function saveTopUp(text, user, queryTime) {
    const amount = parseTopUpAmount(text);
    if (!amount) return { ignored: 'top-up text but no amount found', preview: text.slice(0, 150) };
    const sm = text.match(/^\s*(?:at|from)\s*[:：]\s*(.+)$/im);
    const store = ((sm && sm[1].trim()) || 'UrPay top-up').slice(0, 80);
    const smsTime = parseSmsTime(text);
    const givenTime = smsTime || parseReceivedTime(text, queryTime);
    const purchasedAt = givenTime || Date.now();
    const u = encodeURIComponent(user);
    const hashText = text.replace(/^\s*received\s*[:：].*$/im, '').replace(/\s+/g, ' ').trim();
    const hash = createHash('sha1').update('topup|' + hashText + (smsTime ? '' : '|' + purchasedAt)).digest('hex').slice(0, 12);
    const lastSeen = Number(await (await fetch(`${DB}/users/${u}/smsSeen/${hash}.json`)).json()) || 0;
    const dupWindow = givenTime ? 7 * 24 * 60 * 60 * 1000 : 2 * 60 * 1000;
    if (Date.now() - lastSeen < dupWindow) return { ignored: 'same message already received' };
    await fetch(`${DB}/users/${u}/smsSeen/${hash}.json`, { method: 'PUT', body: JSON.stringify(Date.now()) });
    const id = hash + Date.now().toString(36);
    await fetch(`${DB}/users/${u}/pendingSms/${id}.json`, { method: 'PUT', body: JSON.stringify({ type: 'topup', amount, store, createdAt: Date.now(), purchasedAt }) });
    try {
        const webhook = await (await fetch(`${DB}/users/${u}/discordWebhook.json`)).json();
        if (webhook) {
            const hookUrl = webhook + (webhook.includes('?') ? '&' : '?') + 'wait=true';
            const hr = await fetch(hookUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username: 'Money', content: `💵 Money added to your card: ${amount} ⃁. Open the app to choose where it goes.`, allowed_mentions: { parse: [] } }),
            });
            const hm = await hr.json().catch(() => null);
            if (hm && hm.id) await fetch(`${DB}/users/${u}/sentMessages/${hm.id}.json`, { method: 'PUT', body: JSON.stringify({ at: Date.now() }) });
        }
    } catch { /* ignore */ }
    return { pending: true, topup: true, amount, store };
}

// Saves ONE SMS as a pending purchase. Returns a small result object (never throws for "ignored" texts).
async function saveOne(text, user, queryTime) {
    if (/\botp\b|one.?time|verification|code\s*[:：]/i.test(text)) return { ignored: 'looks like a code message' };
    // Money coming IN (top-up / card charge / deposit). Saved as a pending top-up; the app asks where to add it.
    if (isTopUp(text)) return await saveTopUp(text, user, queryTime);
    if (/refund|reversal|return|credit/i.test(text)) return { ignored: 'refund/credit not handled yet' };
    if (!/amount\s*[:：]/i.test(text)) return { ignored: 'no "amount:" line in the text', preview: text.slice(0, 150) };
    const amount = parseAmount(text);
    if (!amount) return { ignored: 'no amount found', preview: text.slice(0, 150) };
    const store = parseStore(text);

    const smsTime = parseSmsTime(text);
    const givenTime = smsTime || parseReceivedTime(text, queryTime);
    const purchasedAt = givenTime || Date.now();
    const hasRealTime = !!givenTime;

    const u = encodeURIComponent(user);
    // The "received:" line is not part of the SMS, so it is left out of the duplicate check.
    const hashText = text.replace(/^\s*received\s*[:：].*$/im, '').replace(/\s+/g, ' ').trim();
    const hash = createHash('sha1').update(hashText + (smsTime ? '' : '|' + purchasedAt)).digest('hex').slice(0, 12);

    // A text that carries its real purchase time can only be saved ONCE (so a queued text that was sent
    // twice, e.g. the phone lost Wi-Fi halfway, never makes a double purchase). A text with no time at all
    // is only treated as a repeat inside 2 minutes (a phone retry), as before.
    const lastSeen = Number(await (await fetch(`${DB}/users/${u}/smsSeen/${hash}.json`)).json()) || 0;
    const dupWindow = hasRealTime ? 7 * 24 * 60 * 60 * 1000 : 2 * 60 * 1000;
    if (Date.now() - lastSeen < dupWindow) return { ignored: 'same message already received' };
    await fetch(`${DB}/users/${u}/smsSeen/${hash}.json`, { method: 'PUT', body: JSON.stringify(Date.now()) });
    const id = hash + Date.now().toString(36);
    await fetch(`${DB}/users/${u}/pendingSms/${id}.json`, { method: 'PUT', body: JSON.stringify({ amount, store, createdAt: Date.now(), purchasedAt }) });

    // Optional heads-up on Discord (never fails the request).
    try {
        const webhook = await (await fetch(`${DB}/users/${u}/discordWebhook.json`)).json();
        if (webhook) {
            const hookUrl = webhook + (webhook.includes('?') ? '&' : '?') + 'wait=true';
            const hr = await fetch(hookUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username: 'Money', content: `💳 UrPay purchase: ${amount} ⃁ at ${store}. Open the app to choose where it comes from.`, allowed_mentions: { parse: [] } }),
            });
            // Remember the message id so reminders.js can delete it after 14 days.
            const hm = await hr.json().catch(() => null);
            if (hm && hm.id) await fetch(`${DB}/users/${u}/sentMessages/${hm.id}.json`, { method: 'PUT', body: JSON.stringify({ at: Date.now() }) });
        }
    } catch { /* ignore */ }

    return { pending: true, amount, store };
}

export default async function handler(req, res) {
    // The inbox page lives on github.io, so the browser needs permission to read this reply.
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, x-key');
    if (req.method === 'OPTIONS') return res.status(200).end();
    try {
        if (req.method !== 'POST' && req.method !== 'GET') return res.status(405).json({ error: 'use POST' });
        const secret = process.env.SMS_SECRET;
        const given = (req.query && req.query.key) || req.headers['x-key'];
        if (!secret || given !== secret) return res.status(401).json({ error: 'wrong or missing key' });

        const user = String((req.query && req.query.user) || '').trim();
        if (!user || /[.#$\[\]\/|]/.test(user)) return res.status(400).json({ error: 'missing or invalid ?user=' });

        const text = readBody(req) || String((req.query && req.query.text) || '');
        if (!text.trim()) return res.status(400).json({ error: 'empty message' });
        const queryTime = req.query && req.query.time;

        // The whole queue file can be sent in ONE request: the saved texts are separated by a line "~~~".
        if (text.includes('~~~')) {
            const records = text.split('~~~').map((t) => t.trim()).filter((t) => t.length > 10);
            const results = [];
            for (const r of records) results.push(await saveOne(r, user, queryTime));
            return res.status(200).json({ ok: true, batch: true, saved: results.filter((r) => r.pending).length, total: records.length, results });
        }

        return res.status(200).json({ ok: true, ...(await saveOne(text, user, queryTime)) });
    } catch (e) {
        return res.status(500).json({ error: e.message });
    }
}
